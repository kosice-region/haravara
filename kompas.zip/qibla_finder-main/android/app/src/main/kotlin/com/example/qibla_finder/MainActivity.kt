package com.example.qibla_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
